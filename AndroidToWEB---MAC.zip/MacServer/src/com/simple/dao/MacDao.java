package com.simple.dao;
import java.util.List;

import com.simple.bean.Mac; 

public interface MacDao {
	
	/**
	 * 判断Mac是否存在
	 */
	boolean isMacExists(String mac); 
	
	int addMacs(Mac m);
}
