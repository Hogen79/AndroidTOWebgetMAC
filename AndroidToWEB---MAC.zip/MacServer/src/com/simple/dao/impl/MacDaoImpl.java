package com.simple.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.simple.bean.Mac; 
import com.simple.dao.MacDao;
import com.simple.util.DBUtil;

public class MacDaoImpl implements MacDao {

	/**
	 * 判断登陆账号是否存在
	 */
	public boolean isMacExists(String mac) {
		boolean res = false;
		String sql = "select * from mac where mac=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql, new String[]{mac});
			rs = pstmt.executeQuery();
			if(rs.next())
				res = true;
		} catch (SQLException e) {
			res = false;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt, rs);
		}
		
		return res;
	}
 
	public int addMacs(Mac m) {
		//boolean flag = false;
		int flag = 0;
		String sql = "insert into mac(mac,name)values(?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql, new String[]{m.getMac(),m.getName()});
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
		

	}
		
}
