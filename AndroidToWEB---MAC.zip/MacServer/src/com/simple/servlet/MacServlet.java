package com.simple.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import com.simple.dao.MacDao;
import com.simple.dao.impl.MacDaoImpl;

public class MacServlet extends HttpServlet {
	private static final long serialVersionUID = -2801273997474096868L;
	
	private MacDao dao = new MacDaoImpl();
	
	/**
	 * 登陆
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		String mac = request.getParameter("mac");

		boolean bl = dao.isMacExists(mac);
		
		if(bl == true){
			out.print("1");
		} else {
			out.print("0");
		}

		out.flush();
		out.close();
	}
  
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	@Override
	public void destroy() {
		super.destroy();
	}
	
	@Override
	public void init() throws ServletException {
		super.init();
	}

}
