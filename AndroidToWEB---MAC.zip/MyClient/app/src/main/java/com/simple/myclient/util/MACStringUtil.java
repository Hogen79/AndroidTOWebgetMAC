package com.simple.myclient.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.simple.myclient.R;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;


public class MACStringUtil {
	
	public static final int TSET_DEBUG = 0;	
	
	/**
	 * �����ṩ������
	 */
	public static final String MAC_DATA_PROVIDE = "mac";
	
 
 
	/**
	 * �Ƿ񱣳��û��� key
	 */
	public static final String IS_MAC_NAME = "is_save_macname";
	 
	
	/**
	 * �û���  key
	 */
	public static final String MACNAME = "macname";
	 
	    
	/**
	 * ���ȶԻ���
	 * @param context
	 * @param title
	 * @param message
	 * @param canCelable
	 * @param indeterminate
	 */
	public static ProgressDialog createProgressDialog(Context context, String title,
			String message, boolean canCelable, boolean indeterminate) {
		ProgressDialog p = new ProgressDialog(context);
		p.setIcon(R.drawable.progress);
		p.setTitle(title);
		p.setMessage(message);
		p.setCancelable(canCelable);
		p.setIndeterminate(indeterminate);
		return p;
	}

 
	
	 
	
 
}
