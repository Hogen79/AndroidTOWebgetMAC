package com.simple.myclient.util;

public class MacUrlUtil {
	
	/**
	 * mac��ѯURL
	 */
	public static final String SEARCH_URL = "MacServlet?";

}
