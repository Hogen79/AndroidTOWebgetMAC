/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.5.20 : Database - mac
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mac` /*!40100 DEFAULT CHARACTER SET gbk */;

USE `mac`;

/*Table structure for table `mac` */

DROP TABLE IF EXISTS `mac`;

CREATE TABLE `mac` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `mac` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=gbk;

/*Data for the table `mac` */

insert  into `mac`(`id`,`mac`,`name`) values (1,' 00-01-6C-06-A6-29','测试1'),(2,' 00-01-6C-06-A6-36','反倒是公司的法规'),(3,'1','哈哈'),(4,'2','悠悠'),(5,'38:bc:1a:32:e6:701','9999');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
